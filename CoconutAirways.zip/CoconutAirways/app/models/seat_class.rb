class SeatClass < ApplicationRecord

end
