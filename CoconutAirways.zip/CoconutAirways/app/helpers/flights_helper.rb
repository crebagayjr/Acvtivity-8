module FlightsHelper
end
